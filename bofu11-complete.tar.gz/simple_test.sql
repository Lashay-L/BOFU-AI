-- Simple connectivity test
SELECT 'Connected successfully!' as status, current_database() as database_name, current_user as user_name; 